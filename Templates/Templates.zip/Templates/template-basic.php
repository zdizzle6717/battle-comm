<?php include 'parts/head.php'; ?>
    <?php include 'parts/header.php'; ?>
        <?php include 'parts/container-top.php'; ?>
			<!-- Content Here -->
		<?php include 'parts/container-bottom.php'; ?>
<?php include 'parts/footer.php'; ?>