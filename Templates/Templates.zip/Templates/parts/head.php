<!doctype html>
<html ng-app="newsApp" >
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BattleComm: Home</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script type="text/javascript" src="../../js/jquery.magnificant-popup.js"></script>
	<script type="text/javascript" src="../../js/mobile-toggle.js"></script>
    <script type="text/javascript" src="../../js/backtotop.js"></script>
    <link rel="stylesheet" type="text/css" media="screen, print" href="../../css/global.css">
    <link rel="stylesheet" type="text/css" media="screen, print" href="../../css/magnificent-popup/magnificent-popup.css">
</head>