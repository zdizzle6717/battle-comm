<div class="col-lg-6">
  <h2>Full Game Systems List</h2>
  <h4>Armada<br>
    Black Powder<br>
    BoltAction<br>
    Bushido<br>
    Call of Cthulhu: The Card Game<br>
    Chess<br>
    D&amp;D Attack Wing<br>
    DarkAge<br>
    DeadZone<br>
    Dreadball<br>
    Drop Zone Commander<br>
    Dystopian Legions<br>
    Dystopian Wars<br>
    Firestorm Armada<br>
    Firestorm Planetfall<br>
    Flames of War<br>
    Game of Thrones the card game<br>
    Hail Ceaser<br>
    Heavy Gear<br>
    Hero Clicks<br>
    Horus Heresy<br>
    Infinity<br>
    Kings of War<br>
    Magic The Gathering<br>
    Malifaux<br>
    NetRunner<br>
    Pike & Shotte<br>
    Relic Knights<br>
    Robotech<br>
    Saga<br>
    Star Wars Imperial Assault<br>
    Star Trek Attack Wing<br>
    Star Wars the Card Game<br>
    W40K Conquest<br>
    The Lord of the Rings/The Hobbit<br>
    Warhammer 40,000<br>
    Warhammer Fantasy Battle<br>
    Warhammer: Invasion<br>
    Warmachine/Hordes<br>
    Warpath<br>
    Warzone<br>
    Wild West Exodus<br>
    X-Wing<br>
  </h4>
</div>