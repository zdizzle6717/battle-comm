<!-- Jssor Slider Begin -->
<!-- To move inline styles to css file/block, please specify a class name for each element. --> 
<div id="slider2_container" class="homepage_slideshow2">
	<!-- Loading Screen -->
        <div data-u="loading" style="position: absolute; top: 0px; left: 0px;">
            <div style="filter: alpha(opacity=70); opacity: 0.7; position: absolute; display: block;
                top: 0px; left: 0px; width: 100%; height: 100%;">
            </div>
            <div style="position: absolute; display: block; background: url(../images/slideshow/loading.gif) no-repeat center center;
                top: 0px; left: 0px; width: 100%; height: 100%;">
            </div>
        </div>
    <!-- Slides Container -->
    <div data-u="slides" class="slides">
        <div>
            <img data-u="image" src="media/banner.png" alt=""/>
        </div>
        <div>
            <img data-u="image" src="media/banner.png" alt="" />
        </div>
        <div>
            <img data-u="image" src="media/banner.png" alt="" />
        </div>
    </div>
            
    <!--#region Bullet Navigator Skin Begin -->
    <!-- bullet navigator container -->
    <div data-u="navigator" class="jssorb21">
        <!-- bullet navigator item prototype -->
        <div data-u="prototype"></div>
    </div>
    <!--#endregion Bullet Navigator Skin End -->

    <!--#region Arrow Navigator Skin Begin -->
    <!-- Arrow Left -->
    <span data-u="arrowleft" class="jssora21l">
    </span>
    <!-- Arrow Right -->
    <span data-u="arrowright" class="jssora21r">
    </span>
    <!--#endregion Arrow Navigator Skin End -->
    <a style="display: none" href="http://www.jssor.com">Bootstrap Slider</a>
</div>