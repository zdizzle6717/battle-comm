<div class="sociallinks">
<a href="#"><span class="symbol face" style="font-size: 38px;">&#xe427;</span></a><a href="#"><span class="symbol twit" style="font-size: 38px;">&#xe286;</span></a><a href="#"><span class="symbol twit" style="font-size: 38px;">&#xe500;</span></a>
</div>