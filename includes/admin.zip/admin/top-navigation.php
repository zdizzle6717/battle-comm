<a href="#menu" class="menu-link">[+] Main Menu [+]</a>
<nav class="topnav">
	<nav class="top-menu" role="navigation">
    <ul>
        <li class="home"><a href="../../index.php" ></a></li>
        <li class="news"><a href="../../news.php" > </a></li>
        <li class="events"><a href="../../events.php" ></a></li>
        <li class="match"><a href="../../match.php" ></a></li>  
        <li class="store"><a href="../../store.php" ></a></li> 
    </ul>
    </nav>
</nav>